# checked for tbmod core 3.5.0
rm(list=ls())
require(tbmod)
#source(here::here("R","include-v11.R"))
#source(here::here("R","TBVx-run-v1.R"))
taskenvvar="taskID"

paths = set.paths(countries   = "countries", 
                  countrycode = "NAM", 
                  xml         = "NAM3_2_8_9_NAM66of71_optim_tbmod.xml",
                  parameters  = "NAM3_2_8_9_NAM66of71_params_tbmod.csv",
                  targets     = "NAM3_2_8_9_NAM66of71_targets.csv",
                  lglevel     = "DEBUG")

x=run(paths,write.to.file = T)
sum(x$hits$fit)
sum(!x$hits$fit)

set.seed(111)
run.optimizer(paths, lmcontrolcsv = "./levmarq.csv")
# 70 of 72 targets hit :-)
# see [NAM][2024-03-23_01h20m49s][][3_2_8_9][NAM3_2_8_9_NAM66of71_optim][optim].log

newparams = read.csv("countries/NAM/parameters/NAM3_2_8_9_NAM66of71_params.csv")
sel = newparams$choose==T
selparams = newparams[sel,]
new.parameters = selparams$mean
names(new.parameters)=selparams$unique.name
set.seed(111)
run.optimizer(paths, new.parameter.values = new.parameters, lmcontrolcsv = "./levmarq.csv")
# 69 of 72 targets hit i.e. no improvement


