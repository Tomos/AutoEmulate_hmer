# checked for tbmod core 3.4.8
rm(list=ls())
require(tbmod)

# include targets
paths = set.paths(countries   = "countries", 
                  countrycode = "NAM", 
                  xml         = "NAM66of71.xml",
                  targets     = "NAM_71_targets.csv",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)
sum(output$hits$fit !=T)

