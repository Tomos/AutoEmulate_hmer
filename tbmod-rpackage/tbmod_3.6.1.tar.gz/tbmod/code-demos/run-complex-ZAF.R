# checked for tbmod core 3.6.0
rm(list=ls())
require(tbmod)

# source(here::here("R","include-v11.R"))
# source(here::here("R","TBVx-run-v1.R"))
taskenvvar="taskID"

# include targets
paths = set.paths(countries   = "countries", 
                  countrycode = "ZAF", 
                  xml         = "complex-ZAF-36of36-DS.xml",
                  targets     = "target-DS-HIV.csv",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)
sum(!output$hits$fit)

# include targets and parameters replacement file
paths = set.paths(countries   = "countries", 
                  countrycode = "ZAF", 
                  xml         = "complex-ZAF-36of36-DS.xml",
                  parameters  = "input.csv",
                  targets     = "target-DS-HIV.csv",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)
sum(!output$hits$fit)
# clearly not the best set of parameters to replace
