# checked for tbmod core 3.6.0
rm(list=ls())
require(tbmod)
# source(here::here("R","include-v11.R"))
# source(here::here("R","TBVx-run-v1.R"))
taskenvvar="taskID"

# to test renaming stages, stage to states, state
paths = set.paths(countries   = "countries", 
                  countrycode = "ZAF", 
                  xml         = "complex-ZAF-states.xml",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)

# to test diagnostic tests and follow up treatment
paths = set.paths(countries   = "countries", 
                  countrycode = "ZAF", 
                  xml         = "XMLinput_2910_m_diag_test_treat_noHIV.xml",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)

