rm(list=ls())
require(tbmod)
#source(here::here("R","include-v11.R"))
#source(here::here("R","TBVx-run-v1.R"))
taskenvvar="taskID"
paths = set.paths(countries   = "countries", 
                  countrycode = "IND", 
                  xml         = "XMLinput_NIH2.xml",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)

paths = set.paths(countries   = "countries", 
                  countrycode = "IND", 
                  xml         = "XMLinput_under.xml",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)

paths = set.paths(countries   = "countries", 
                  countrycode = "IND", 
                  xml         = "XMLinput_under.xml",
                  parameters  = "input_under.csv",
                  targets     = "target_under.csv",
                  lglevel     = "INFO")
output=run(paths,write.to.file = T)
output$hits$fit

# better fit:
paths = set.paths(countries   = "countries", 
                  countrycode = "IND", 
                  xml         = "XMLinput_under_pT0_0003.xml",
                  targets     = "target_under.csv",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)
output$hits$fit
