rm(list=ls())
require(tbmod)
#source(here::here("R","include-v11.R"))
#source(here::here("R","TBVx-run-v1.R"))
taskenvvar="taskID"

# include targets and parameters replacement file
# note that the currently used parameters do not fit the targets very well
paths = set.paths(countries   = "countries", 
                  countrycode = "ZAF", 
                  xml         = "complex-ZAF-36of36-5yrag-orig-Cm-DS.xml",
                  parameters  = "input.csv",
                  targets     = "target-DS-HIV.csv",
                  lglevel     = "INFO")

output=run(paths,write.to.file = T)
sum(output$hits$fit !=T)

# include targets and parameters replacement file and use sampled parameter values
df = read.csv(file="./countries/ZAF/parameters/paramsets.csv")
for (i in 1:nrow(df)){
  p = as.numeric(df[i,3:ncol(df)])
  names(p)=names(df[3:ncol(df)])
  cat("i=",i,"\n")
  z=run(paths, new.parameter.values = p)
  print(paste0(sum(z$hits$fit)," hits out of ",length(z$hits$fit)," targets"))
}
# now run the optimizer for each of the parameter sets (and select the 36 of 36 hits from the log file)
# or just try i=2

for (i in 1:nrow(df)){
  p = as.numeric(df[i,3:ncol(df)])
  names(p)=names(df[3:ncol(df)])
  cat("i=",i,"\n")
  set.seed(111)
  run.optimizer(paths = paths, new.parameter.values = p, lmcontrolcsv ="./levmarq.csv")
}
# i = 2 : 36 of 36 with SSWR=4.428 which is exceptionally good.... 
# this occurs after 521 simulation runs i.e. 43 minutes which isn't too bad
