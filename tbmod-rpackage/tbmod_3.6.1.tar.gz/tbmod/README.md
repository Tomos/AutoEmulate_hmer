# TBmod core R package 3.6.1 with examples

See ./code-demos/*.R

# TBmod core R package 3.6.0 with examples

See ./code-demos/*.R

# TBmod core R package 3.5.0 with examples

This repository is for accessing packaged versions of tbmod and for developing of the model's source code. 

Each new branch should contain a version-history.md file to keep a detailed and chronological record of changes made to each model version. Please see that version-history.md file for details on how to add an entry. 

# Prerequisites
Make sure you have installed   
1. R   
2. RStudio (see https://posit.co/download/rstudio-desktop/)

# How to use

1. clone this repository to your local system using GitHub Desktop

2. open **tbmod-core-rpackage.Rproj** using RStudio 

3. install the tbmod source package from **tbmod-rpackage/tbmod_3.5.0.tar.gz** on your local system   
   note: use the option Install from:Package Archive in RStudio

4. read **version-history.md** 

5. read the tbvax **vignettes** : find the tbvax package in RStudio under **'Packages'** and click on **tbmod**  

6. inspect and run the example R scripts  
   **code-demos/run-SIR-SEIRx2.R**  
   **code-demos/run-complex-ZAF.R**  
   **code-demos/run-complex-ZAF-Vx.R**  

7. inspect the output files in **countries/ZAF/output/** and the log files in **countries/ZAF/logs/** 
