noquote("INSTRUCTIONS FOR USING PACKAGED VERSION OF TBVAX:")
cat("\n")
cat("\n")

suppressPackageStartupMessages({
  library(assertthat)
  library(here)
  library(base)
  library(utils)
})

# Checking that the expected directory structures are present:
expected_dirs <- c(
  paste0("rpackage/")
)

#path_env <- Sys.getenv("PATH")
#print(path_env)

noquote(paste0("Expected directory structure for each model: "))
noquote(paste0("./", expected_dirs))
noquote(paste0("Was expected directory structure found? "))
exist_status1 <- dir.exists(file.path(expected_dirs))
assert_that(isTRUE(unique(exist_status1)), msg = paste0("Desired file structure not found"))

cat("\n")

# List tarball (there should only be one)
tarball <- list.files(path = here("rpackage"), pattern = "\\.tar\\.gz$")
#print(tarball)
noquote(paste0("Checking whether a single tarball was found: "))
assert_that(length(tarball) == 1, msg = "ERROR - Multiple tarball files found for tbvax")
cat("\n")
cat("\n")

if("tbvax" %in% rownames(installed.packages())){ # if tbvax is already installed

  print(noquote(paste0("Tbvax already installed")))
  
  print(noquote("If you want to ensure the correct version of tbvax is being used:"))
  cat("\n")
  print(noquote("Detach the current version of tbvax:"))
  print(noquote("detach(package:tbvax, unload=TRUE)"))
  cat("\n")
  print(noquote("Removeing tbvax with:"))
  print(noquote("remove.packages('tbvax')"))
  cat("\n")
  print(noquote(paste0("Install the ", tarball, " tarball for tbvax in this project directory using: ")))
  print(noquote("install.packages(here('rpackage', tarball), repos = NULL, type = 'source')"))
  cat("\n")
  print(noquote("And load tbvax package with:"))
  print(noquote("library(tbvax)"))
  cat("\n")
  print(noquote("Check tbvax model version with: "))
  print(noquote("packageVersion('tbvax')"))
  
  # Check if tbvax is already loaded:
  if((paste("package:", "tbvax", sep = "") %in% search())){
    detach(package:tbvax, unload=TRUE)
  }
  #remove.packages("tbvax")
  #install.packages(here("rpackage", tarball), repos = NULL, type = "source")
  #library(tbvax)
  
  cat("\n")
  cat("\n")
  cat("\n")
  print(noquote(paste0("Current packaged version of tbvax being used: ", packageVersion("tbvax"))))
  cat("\n")
  cat("\n")
}else{

  print(noquote("No tbvax package detected"))
  cat("\n")
  print(noquote(paste0("To install the ", tarball, " tarball for tbvax in this project directory, use: ")))
  print(noquote("install.packages(here('rpackage', tarball), repos = NULL, type = 'source')"))
  cat("\n")
  print(noquote("And load tbvax package with:"))
  print(noquote("library(tbvax)"))
  cat("\n")
  print(noquote("Check tbvax model version with: "))
  print(noquote("packageVersion('tbvax')"))
  
  #install.packages(here("rpackage", tarball), repos = NULL, type = "source")
  #library(tbvax)
  #print(noquote(paste0("Current version of tbvax being used: ", packageVersion("tbvax"))))
}

