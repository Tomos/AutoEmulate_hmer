noquote("Loading tbvax model from the scripts present at this project directory")
cat("\n")
cat("\n")

suppressPackageStartupMessages({
  library(assertthat)
  library(here)
  library(base)
  library(utils)
})

### MODIFICATION TO ADD:
# Unpack the tarball and use these R scripts

# Checking that the expected directory structures are present:
expected_dirs <- c(
  paste0("R/")
)

noquote(paste0("Expected directory structure for each model: "))
noquote(paste0("./", expected_dirs))
noquote(paste0("Was expected directory structure found? "))
exist_status1 <- dir.exists(file.path(expected_dirs))
assert_that(isTRUE(unique(exist_status1)), msg = paste0("Desired file structure not found"))

cat("\n")
cat("\n")

if((paste("package:", "tbvax", sep = "") %in% search())){
  detach(package:tbvax, unload=TRUE)
}

# Listing the R scripts and leading each one
tbvax_R_files <- list.files(path = here("R"), pattern = "\\.R$", full.names = TRUE)

for(i in 1:length(tbvax_R_files)){
  focal_R_script <- tbvax_R_files[i]
  source(focal_R_script)
}

