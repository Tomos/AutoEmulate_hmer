**tbvax** was written in R. 

The version of R and the R packages used (use sessionInfo() in R) in model version 3.1.4:

`R version 4.1.1 (2021-08-10)`

`Platform: x86_64-w64-mingw32/x64 (64-bit)`

`Running under: Windows 10 x64 (build 19042)`

`Matrix products: default`

`locale:`

`LC_COLLATE=English_United Kingdom.1252 `
`LC_CTYPE=English_United Kingdom.1252   `
`LC_MONETARY=English_United Kingdom.1252`
`LC_NUMERIC=C                           `
`LC_TIME=English_United Kingdom.1252    `


`attached base packages:` 

`tools`
`stats`
`graphics`
`grDevices`
`datasets`
`utils`
`methods`
`base`

`other attached packages:` 

`arrow_5.0.0.2`
`log4r_0.3.2`
`lubridate_1.8.0`
`minpack.lm_1.2-1`
`fst_0.9.4`
`data.table_1.14.2`
`deSolve_1.30`  
`digest_0.6.28`
`xml2_1.3.2`
`Matrix_1.3-4`
`stringi_1.7.5`
`assertthat_0.2.1`
`here_1.0.1`

 

